import React from 'react'

export const success = () => {
  return (
    <div>success</div>
  )
}
