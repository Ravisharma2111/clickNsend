export { default } from './NavSectionVertical';
