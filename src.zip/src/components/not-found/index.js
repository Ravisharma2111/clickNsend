export { default as JobSekelton } from "./jobList/job";
